import Models as mod

class StudentDAO:
    students = []
    def __init__(self):
        with open('students.csv', 'r') as k:
            stdln = k.read().splitlines()
            self.students = []
            for student in stdln:
                info_list = student.split(',')
                self.students.append(mod.Student(info_list[0], info_list[1], info_list[2]))              
    def get_students(self):
        return self.students           
    def validate_user(self, email, pw):
        for b in range(len(self.students)):
            if self.students[b].email == email and self.students[b].password == pw:
                return True
        else:
            return False    
    def get_student_by_email(self, email):
        for c in range(len(self.students)):
            if self.students[c].email == email:
                return self.students[c] 
          
class CourseDAO:
    all_course = []
    def __init__(self):
        with open('courses.csv', 'r') as k:
            course_lines = k.read().splitlines()
            self.courses = []
            for course in course_lines:
                ilist = course.split(',')
                self.courses.append(mod.Course(ilist[0], ilist[1], ilist[2]))     
    def get_courses(self):
        return self.courses  
    
class AttendingDAO:
    def __init__(self):
        with open('attending.csv', 'r') as k:
            lines = k.read().splitlines()
            self.attending = []
            for line in lines:
                c_id, email = line.split(',')[0], line.split(',')[1]
                self.attending.append(mod.Attending(c_id, email))      
    def get_attending(self):
        return self.attending

    def get_student_courses(self, course_list, email):
        self.student_course_ids = [i.course_id for i in self.attending if i.student_email == email]
        self.student_courses = []
        for i in self.student_course_ids:
            for h in course_list:
                if i == h.course_id:
                    self.student_courses.append(h)
        return self.student_courses
        
    def register_student_to_course(self, email, course_id, course_list):
        course_id_list = [course.get_id() for course in course_list]
        course_email = [course_id, email]
        if course_email in [[course.course_id, course.student_email] for course in self.attending]:
            print('\nYou Are Already Registered In The Course.')
            return False
        elif course_id not in course_id_list:
            print('\nNot A Valid Course ID Number...')
            return False
        else:
            self.attending.append(mod.Attending(course_id, email))
            self.save_attending()
            print('\nRegistration Successful!')
            return True
        
    def save_attending(self):
        attending_data = ''
        for i in self.attending:
            attending_data+=(f'{i.course_id},{i.student_email}')
        with open('attending.csv', 'w') as t:
            t.write(attending_data)
    
    